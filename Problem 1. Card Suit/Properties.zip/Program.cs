﻿using System;

public class Program
{
    static void Main(string[] args)
    {
        CardReader card1 = new CardReader(Console.ReadLine(), Console.ReadLine());
        CardReader card2 = new CardReader(Console.ReadLine(), Console.ReadLine());

        if (card1.CompareTo(card2) > 0)
        {
            Console.WriteLine(card1);
        }
        else
        {
            Console.WriteLine(card2);
        }

    }
}

