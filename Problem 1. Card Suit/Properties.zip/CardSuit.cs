﻿public enum CardSuit
{
    Clubs,
    Hearts = 26,
    Diamonds = 13,
    Spades = 39
}

